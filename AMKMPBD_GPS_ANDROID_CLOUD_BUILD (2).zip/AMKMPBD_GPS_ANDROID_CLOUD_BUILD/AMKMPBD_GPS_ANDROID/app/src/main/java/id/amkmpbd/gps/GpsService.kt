package id.amkmpbd.gps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.TimeZone

class GpsService : Service() {
    companion object { const val ACTION_START = "id.amkmpbd.gps.START"; const val ACTION_STOP = "id.amkmpbd.gps.STOP"; private const val CHANNEL = "amkmpbd_gps" }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var client: FusedLocationProviderClient
    private var callback: LocationCallback? = null
    private var nip = ""; private var nama = ""; private var unit = ""; private var shifts = JSONArray()
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastWrite = 0L
    private var scheduleJob: Job? = null
    private var tracking = false

    override fun onCreate() { super.onCreate(); client = LocationServices.getFusedLocationProviderClient(this); createChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopTracking("OUT"); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            nip = intent.getStringExtra("nip") ?: nip; nama = intent.getStringExtra("nama") ?: nama; unit = intent.getStringExtra("unit") ?: unit
            shifts = try { JSONArray(intent.getStringExtra("shifts") ?: "[]") } catch (_: Exception) { JSONArray() }
            getSharedPreferences("gps_session", MODE_PRIVATE).edit().putString("nip", nip).putString("nama", nama).putString("unit", unit).putString("shifts", shifts.toString()).apply()
        } else if (nip.isBlank()) {
            val prefs = getSharedPreferences("gps_session", MODE_PRIVATE)
            nip = prefs.getString("nip", "") ?: ""; nama = prefs.getString("nama", "") ?: ""; unit = prefs.getString("unit", "") ?: ""
            shifts = try { JSONArray(prefs.getString("shifts", "[]")) } catch (_: Exception) { JSONArray() }
        }
        if (nip.isBlank()) { stopSelf(); return START_NOT_STICKY }
        startForeground(2026, notification("GPS dinas aktif • $nama"))
        try { wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AMKMPBD:GPS").apply { setReferenceCounted(false); acquire(10 * 60 * 60 * 1000L) } } catch (_: Exception) {}
        beginLocation()
        if (scheduleJob?.isActive != true) scheduleJob = scope.launch {
            while (isActive) {
                delay(60_000)
                if (dutyNow().first && !tracking) {
                    withContext(Dispatchers.Main) { beginLocation() }
                    updateNotification("Jadwal dinas aktif • GPS dimulai • $nama")
                } else if (!dutyNow().first && tracking) {
                    writeStatus("OUT", false, "DI LUAR JAM DINAS")
                    withContext(Dispatchers.Main) { pauseTracking("Menunggu jadwal dinas berikutnya") }
                }
            }
        }
        return START_STICKY
    }

    private fun beginLocation() {
        if (tracking) return
        tracking = true
        try { wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AMKMPBD:GPS").apply { setReferenceCounted(false); acquire(10 * 60 * 60 * 1000L) } } catch (_: Exception) {}
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 20_000L).setMinUpdateIntervalMillis(10_000L).setMaxUpdateDelayMillis(30_000L).build()
        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                scope.launch {
                    if (!dutyNow().first) { writeStatus("OUT", false, "DI LUAR JAM DINAS"); withContext(Dispatchers.Main) { pauseTracking("Menunggu jadwal dinas berikutnya") }; return@launch }
                    val now = System.currentTimeMillis()
                    val data = JSONObject().apply {
                        put("nama", nama); put("unit", unit); put("shift", dutyNow().second)
                        put("latitude", loc.latitude); put("longitude", loc.longitude); put("accuracy", loc.accuracy.toDouble())
                        put("status", "Aktif"); put("online", true); put("lokasi", "GPS AKTUAL"); put("updateAt", loc.time)
                    }
                    try {
                        putJson("sebaran_personil/$nip.json", data)
                        if (now - lastWrite >= 60_000L) {
                            val hist = JSONObject(data.toString()).apply { put("capturedAt", loc.time); put("receivedAt", now) }
                            putJson("sebaran_personil_history/$nip/${loc.time}.json", hist)
                            lastWrite = now
                        }
                        updateNotification("GPS aktif • $nama • update ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale("id", "ID")).format(java.util.Date(loc.time))}")
                    } catch (_: Exception) { updateNotification("GPS terbaca • menunggu koneksi Firebase") }
                }
            }
        }
        callback = cb
        try { client.requestLocationUpdates(req, cb, Looper.getMainLooper()) }
        catch (_: SecurityException) { stopTracking("IZIN LOKASI DICABUT") }
    }

    private fun dutyNow(): Pair<Boolean, String> {
        val c = Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta")); val minute = c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE); val day = c.get(Calendar.DAY_OF_MONTH)
        val code = if (day in 1..shifts.length()) shifts.optString(day-1).uppercase() else ""
        if (minute < 360 && day > 1 && shifts.optString(day-2).uppercase() == "M") return true to "M"
        if (code in listOf("L", "OFF", "O", "LIBUR") || code.isBlank()) return false to code
        val norm = if (code == "MD" || code == "MD1") "P" else code
        val on = when (norm) { "P" -> minute in 360 until 840; "S" -> minute in 840 until 1320; "M" -> minute >= 1320 || minute < 360; else -> false }
        return on to code
    }

    private suspend fun writeStatus(status: String, online: Boolean, reason: String) {
        if (nip.isBlank()) return
        try { patchJson("sebaran_personil/$nip.json", JSONObject().apply { put("nama",nama);put("unit",unit);put("shift",dutyNow().second);put("status",status);put("online",online);put("lokasi",reason);put("updateAt",System.currentTimeMillis()) }) } catch (_: Exception) {}
    }

    private fun patchJson(path: String, body: JSONObject) {
        val url = URL("https://cc-pam-bandung-default-rtdb.asia-southeast1.firebasedatabase.app/$path")
        val conn = (url.openConnection() as HttpURLConnection).apply { requestMethod="PATCH"; connectTimeout=10_000; readTimeout=10_000; doOutput=true; setRequestProperty("Content-Type","application/json; charset=utf-8") }
        try { conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }; val code=conn.responseCode; if (code !in 200..299) throw IllegalStateException("Firebase HTTP $code"); conn.inputStream?.close() } finally { conn.disconnect() }
    }

    private fun putJson(path: String, body: JSONObject) {
        val url = URL("https://cc-pam-bandung-default-rtdb.asia-southeast1.firebasedatabase.app/$path")
        val conn = (url.openConnection() as HttpURLConnection).apply { requestMethod="PUT"; connectTimeout=10_000; readTimeout=10_000; doOutput=true; setRequestProperty("Content-Type","application/json; charset=utf-8") }
        try { conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }; val code=conn.responseCode; if (code !in 200..299) throw IllegalStateException("Firebase HTTP $code"); conn.inputStream?.close() } finally { conn.disconnect() }
    }

    private fun pauseTracking(reason: String) {
        callback?.let { client.removeLocationUpdates(it) }; callback=null; tracking=false
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}; wakeLock=null
        updateNotification(reason)
    }

    private fun stopTracking(reason: String) {
        if (nip.isNotBlank()) scope.launch { writeStatus("OUT", false, reason) }
        pauseTracking(reason)
        scheduleJob?.cancel(); scheduleJob=null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() { callback?.let { client.removeLocationUpdates(it) }; scheduleJob?.cancel(); try { wakeLock?.let { if(it.isHeld) it.release() } } catch (_: Exception) {}; scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val ch=NotificationChannel(CHANNEL,"AMKMPBD GPS Dinas",NotificationManager.IMPORTANCE_LOW).apply { description="Menunjukkan layanan GPS personil yang sedang berjalan" }; (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch) } }
    private fun notification(text: String): Notification = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("AMKMPBD • GPS Personil").setContentText(text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build()
    private fun updateNotification(text: String) { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2026, notification(text)) }
}
