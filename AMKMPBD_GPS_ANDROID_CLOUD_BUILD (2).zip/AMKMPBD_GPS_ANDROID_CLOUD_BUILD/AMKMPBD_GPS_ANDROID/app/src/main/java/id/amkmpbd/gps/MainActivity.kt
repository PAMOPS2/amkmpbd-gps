package id.amkmpbd.gps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val req = 771
    private lateinit var nipInput: EditText
    private lateinit var info: TextView
    private lateinit var start: Button
    private var selected: JSONObject? = null
    private var shifts = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3, 21, 46)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(3, 21, 46))
        }
        fun text(value: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(android.graphics.Color.WHITE)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }
        root.addView(text("AMKMPBD • GPS PERSONIL", 23f, true))
        root.addView(text("GPS mengikuti jadwal dinas • Firebase Realtime Database", 13f))
        nipInput = EditText(this).apply {
            hint = "Masukkan NIPKWT"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true); textSize = 18f; setPadding(16, 12, 16, 12)
            setTextColor(android.graphics.Color.WHITE); setHintTextColor(0xFF9DB7D5.toInt())
            setBackgroundColor(0xFF082A50.toInt())
        }
        root.addView(nipInput, LinearLayout.LayoutParams(-1, 58).apply { topMargin = 24 })
        val validate = Button(this).apply { text = "CEK NIPKWT & JADWAL" }
        root.addView(validate, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 10 })
        info = text("Masukkan NIPKWT yang terdaftar pada master personil.", 14f)
        root.addView(info)
        start = Button(this).apply { text = "MULAI DINAS & AKTIFKAN GPS"; isEnabled = false }
        root.addView(start, LinearLayout.LayoutParams(-1, 58).apply { topMargin = 10 })
        val stop = Button(this).apply { text = "SELESAI DINAS / HENTIKAN GPS" }
        root.addView(stop, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 8 })
        root.addView(text("PENTING: tekan MULAI saat aplikasi terbuka. Izinkan lokasi dan notifikasi. Jangan paksa berhenti aplikasi. Android dapat membatasi pelacakan jika izin dicabut atau aplikasi dihentikan paksa.", 12f))
        setContentView(root)

        validate.setOnClickListener {
            val nip = nipInput.text.toString().trim()
            val p = loadMaster().firstOrNull { it.optString("nip") == nip }
            if (p == null) {
                selected = null; start.isEnabled = false; info.text = "NIPKWT tidak ditemukan di master personil."; return@setOnClickListener
            }
            selected = p
            shifts = p.optJSONArray("shifts") ?: JSONArray()
            val duty = dutyNow(shifts)
            info.text = "${p.optString("nama")} • ${p.optString("unit")}\nJadwal: ${duty.second}\n${if (duty.first) "JADWAL AKTIF" else "DI LUAR JAM DINAS / LIBUR"}"
            start.isEnabled = duty.first
            start.text = if (duty.first) "MULAI DINAS & AKTIFKAN GPS" else "GPS TIDAK AKTIF DI LUAR JAM DINAS"
        }
        start.setOnClickListener {
            val p = selected ?: return@setOnClickListener
            if (!hasPermissions()) {
                val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                ActivityCompat.requestPermissions(this, perms.toTypedArray(), req)
            } else startServiceFor(p)
        }
        stop.setOnClickListener {
            val i = Intent(this, GpsService::class.java).setAction(GpsService.ACTION_STOP)
            startService(i)
            Toast.makeText(this, "Perintah berhenti dikirim", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasPermissions(): Boolean {
        val loc = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val notif = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        return loc && notif
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == req) {
            val p = selected
            if (p != null && hasPermissions()) startServiceFor(p)
            else Toast.makeText(this, "Izin lokasi dan notifikasi diperlukan untuk GPS dinas", Toast.LENGTH_LONG).show()
        }
    }

    private fun startServiceFor(p: JSONObject) {
        val duty = dutyNow(p.optJSONArray("shifts") ?: JSONArray())
        if (!duty.first) { Toast.makeText(this, "Di luar jam dinas: ${duty.second}", Toast.LENGTH_LONG).show(); return }
        val i = Intent(this, GpsService::class.java).apply {
            action = GpsService.ACTION_START
            putExtra("nip", p.optString("nip")); putExtra("nama", p.optString("nama")); putExtra("unit", p.optString("unit"))
            putExtra("shifts", (p.optJSONArray("shifts") ?: JSONArray()).toString())
        }
        ContextCompat.startForegroundService(this, i)
        info.text = "GPS dinas dimulai. Kunci layar untuk menguji; periksa indikator Firebase pada Command Center."
        Toast.makeText(this, "GPS dinas dimulai", Toast.LENGTH_SHORT).show()
    }

    private fun loadMaster(): List<JSONObject> {
        val raw = assets.open("master_personil.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw); return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    private fun dutyNow(s: JSONArray): Pair<Boolean, String> {
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta"))
        val minute = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        val day = c.get(java.util.Calendar.DAY_OF_MONTH)
        val code = if (day in 1..s.length()) s.optString(day - 1).uppercase() else ""
        if (minute < 360 && day > 1 && s.optString(day - 2).uppercase() == "M") return true to "M • 22:00–06:00 (lanjutan kemarin)"
        if (code == "L" || code == "OFF" || code.isBlank()) return false to if (code.isBlank()) "Jadwal tidak ditemukan" else "L • LIBUR"
        val norm = if (code == "MD" || code == "MD1") "P" else code
        val range = when (norm) { "P" -> 360 until 840; "S" -> 840 until 1320; "M" -> if (minute >= 1320 || minute < 360) (1320..1439) + (0..359) else emptyList<Int>(); else -> emptyList<Int>() }
        val on = minute in range
        val jam = when (norm) { "P" -> "06:00–14:00"; "S" -> "14:00–22:00"; "M" -> "22:00–06:00"; else -> "Tidak diketahui" }
        return on to "$code • $jam"
    }
}
