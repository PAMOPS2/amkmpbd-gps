# AMKMPBD GPS Android — paket build cloud

## Isi
- Aplikasi Android Kotlin untuk mengirim GPS ke Firebase saat layanan lokasi foreground berjalan.
- Master 38 personil disalin dari file `1. PERSONIL_GPS_REALTIME_FIX_SHIFT_MALAM.html` yang diberikan.
- Path posisi terakhir: `sebaran_personil/{NIPKWT}`.
- Path histori: `sebaran_personil_history/{NIPKWT}/{timestamp}` (sekitar satu titik per menit).
- GitHub Actions workflow untuk membangun APK debug tanpa Android Studio lokal.

## Cara menghasilkan APK tanpa Android Studio
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository (file `settings.gradle.kts` harus di root).
3. Buka tab **Actions** dan jalankan **Build AMKMPBD GPS APK** (atau push ke branch `main`).
4. Buka run workflow yang selesai, unduh artifact `AMKMPBD-GPS-APK`, lalu ekstrak `app-debug.apk`.
5. Pasang APK pada HP uji coba. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

## Pemakaian
1. Buka aplikasi, masukkan NIPKWT, lalu tekan CEK NIPKWT & JADWAL.
2. Saat jam dinas aktif, tekan MULAI DINAS & AKTIFKAN GPS saat aplikasi terbuka di layar.
3. Izinkan lokasi dan notifikasi. Layanan berjalan dengan notifikasi persisten saat layar terkunci.
4. Uji terlebih dahulu pada satu HP; cek `sebaran_personil/{NIPKWT}` di Firebase dan dashboard.

## Batasan penting
- Ini adalah **proyek siap build melalui GitHub Actions**, bukan APK yang sudah dikompilasi dan ditandatangani rilis.
- Versi ini memakai jadwal 38 personil yang tertanam dari file sumber. Jika master/jadwal berubah, asset `app/src/main/assets/master_personil.json` harus diperbarui lalu build ulang.
- Layanan mengikuti jadwal setelah diaktifkan oleh personil. Android membatasi aplikasi untuk memulai pelacakan lokasi secara otomatis dari kondisi berhenti; untuk keandalan, personil perlu membuka aplikasi dan menekan Mulai saat awal dinas. Jangan paksa berhenti aplikasi, cabut izin, atau mematikan lokasi.
- Pengiriman langsung menggunakan Firebase Realtime Database REST API. Aturan database harus mengizinkan write untuk path tersebut. **Jangan membuka akses write global ke publik untuk produksi.** Untuk deployment aman, tambahkan Firebase Authentication dan Security Rules yang mengikat setiap pengguna ke NIPKWT.
- Histori memakai path `sebaran_personil_history`. Pastikan aturan Firebase juga mengizinkan write hanya untuk pengguna yang berwenang. Jika write histori ditolak, posisi terakhir tetap dicoba ditulis pada path utama.
- Jam shift ditafsirkan Asia/Jakarta: P 06–14, S 14–22, M 22–06, MD/MD1 sebagai P (06–14), L/OFF/libur tidak aktif. Validasi aturan MD/MD1 dengan kebijakan jadwal resmi sebelum dipakai operasional.
- Timestamp posisi berasal dari lokasi Android; pengiriman histori dibatasi sekitar sekali per menit. Uji shift malam dan pergantian bulan/tanggal sebelum dipakai massal.
